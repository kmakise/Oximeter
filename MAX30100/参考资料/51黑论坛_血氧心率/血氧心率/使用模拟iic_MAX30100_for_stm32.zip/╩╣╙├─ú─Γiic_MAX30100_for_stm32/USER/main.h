#ifndef __MAIN_H
#define __MAIN_H
#include "stm32f10x.h"

extern u16 Already_Rotation_Number;
extern u8 Bit_Test;
extern u8 Bit_Limit;

extern u8  Bit_Coder_add;//��
extern u8  Bit_Coder_red;//��
extern u8 dis_data[5];

#endif
